import os
from sqlalchemy import create_engine
from models import Base, User
from utils import hash_password

DB_URL = os.environ.get("DATABASE_URL", "sqlite:///data.db")
engine = create_engine(DB_URL, echo=False)
Base.metadata.drop_all(engine)
Base.metadata.create_all(engine)

# default admin
from sqlalchemy.orm import Session
with Session(engine) as s:
    admin = User(username="admin", password_hash=hash_password("admin123"), is_admin=True)
    s.add(admin)
    s.commit()
print("Database reset. Admin user: admin / admin123")
