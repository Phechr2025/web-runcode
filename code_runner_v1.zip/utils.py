import os, re, unicodedata, hashlib

def slugify(value: str) -> str:
    value = unicodedata.normalize('NFKD', value).encode('ascii', 'ignore').decode('ascii')
    value = re.sub(r'[^a-zA-Z0-9\-\_]+', '-', value).strip('-').lower()
    return re.sub('-{2,}', '-', value) or 'project'

def hash_password(pw: str) -> str:
    # simple salted sha256 (for demo; replace with argon2/bcrypt in prod)
    salt = 'v1$static_salt'
    return hashlib.sha256((salt + pw).encode()).hexdigest()

def verify_password(pw: str, hashed: str) -> bool:
    return hash_password(pw) == hashed
