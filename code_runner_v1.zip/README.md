# VPS Code Runner v1 (Replit-like MVP)

ฟีเจอร์หลัก
- สมัครสมาชิก / ล็อกอิน
- สร้างโปรเจกต์ **v1** พร้อมบันทึกลงฐานข้อมูล
- เลือกภาษาได้สูงสุด 5 ภาษา (จาก: Python, Node, PHP, Java, Go)
- ตัวแก้ไขไฟล์แบบง่าย + บันทึกลงดิสก์และฐานข้อมูล
- กด **Run** เพื่อรันโค้ดใน Docker ของแต่ละภาษา (รวมผลลัพธ์แสดงหน้า Console)
- โครงสร้างโฟลเดอร์ seed คล้ายเมนูไฟล์ในรูป (behavior_packs, config, definitions, resource_packs)

## การติดตั้งบน VPS (แนะนำ Ubuntu 22.04+)

```bash
# 1) อัปเดตระบบ + ติดตั้ง Docker
sudo apt update && sudo apt upgrade -y
sudo apt install -y ca-certificates curl gnupg
sudo install -m 0755 -d /etc/apt/keyrings
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /etc/apt/keyrings/docker.gpg
echo   "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu   $(. /etc/os-release && echo $VERSION_CODENAME) stable" |   sudo tee /etc/apt/sources.list.d/docker.list > /dev/null

sudo apt update
sudo apt install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin

# 2) อนุญาตให้ผู้ใช้ปัจจุบันใช้ docker โดยไม่ต้อง sudo (ต้อง logout/login ใหม่ครั้งเดียว)
sudo usermod -aG docker $USER

# 3) เตรียมโฟลเดอร์ app
sudo mkdir -p /opt/code_runner_v1
sudo chown -R $USER:$USER /opt/code_runner_v1

# 4) อัปโหลดไฟล์โปรเจกต์ (โฟลเดอร์นี้) ไปไว้ที่ /opt/code_runner_v1
# หรือใช้ git clone ก็ได้

cd /opt/code_runner_v1
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt

# 5) ตั้งค่า .env
cp .env.example .env
nano .env
# แนะนำให้ตั้ง WORKSPACE_BASE=/opt/code_runner_v1/workspaces
mkdir -p /opt/code_runner_v1/workspaces

# 6) รีเซ็ตฐานข้อมูล (จะลบข้อมูลเก่าทั้งหมดตามที่ร้องขอ)
python db_init.py

# 7) รันแอป
python app.py
# หรือ production
# gunicorn -k gevent -w 1 -b 0.0.0.0:8080 app:app
```

เปิดเบราว์เซอร์ไปที่ `http://<VPS-IP>:8080`  
บัญชีแอดมินเริ่มต้น: `admin / admin123` (เปลี่ยนรหัสในภายหลัง)

## หมายเหตุ
- การรันโค้ดพึ่งพา Docker images ต่อภาษา: python, node, php, openjdk, golang
- ในหน้า Run จะรันตามภาษาที่เลือกไว้และรวม log มาแสดง (แบบ sequential เพื่อความง่าย)
- หากต้องการ Live Console ให้ต่อยอดด้วย WebSocket/Flask-SocketIO
- ระบบนี้เป็น MVP สำหรับ v1: เน้นใช้งานง่ายและปลอดภัยระดับเบื้องต้น (ควรเพิ่ม sandbox/limit ตามต้องการ)
