import os, json, subprocess, shlex, time, pathlib
from datetime import datetime
from flask import Flask, render_template, request, redirect, url_for, flash, session, send_from_directory, jsonify
from sqlalchemy import create_engine, select
from sqlalchemy.orm import Session
from dotenv import load_dotenv
from models import Base, User, Project, FileRecord, Run
from utils import slugify, hash_password, verify_password

load_dotenv()
APP_NAME = os.environ.get("APP_NAME", "VPS Code Runner v1")
WORKSPACE_BASE = os.environ.get("WORKSPACE_BASE", "/workspaces")
DOCKER_BIN = os.environ.get("DOCKER_BIN", "/usr/bin/docker")
DB_URL = os.environ.get("DATABASE_URL", "sqlite:///data.db")

engine = create_engine(DB_URL, echo=False)
Base.metadata.create_all(engine)

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "dev-key")

# load runner spec
with open("runtime/runners.json", "r", encoding="utf-8") as f:
    RUNNERS = json.load(f)

def current_user():
    uid = session.get("uid")
    if not uid:
        return None
    with Session(engine) as s:
        return s.get(User, uid)

@app.context_processor
def inject_globals():
    return dict(APP_NAME=APP_NAME)

# ---------- Auth ----------
@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form["username"].strip()
        password = request.form["password"].strip()
        with Session(engine) as s:
            if s.scalar(select(User).where(User.username == username)):
                flash("ชื่อผู้ใช้นี้มีอยู่ในระบบแล้ว", "danger")
                return redirect(url_for("register"))
            u = User(username=username, password_hash=hash_password(password))
            s.add(u)
            s.commit()
            flash("สมัครสมาชิกสำเร็จ ล็อกอินได้เลย", "success")
            return redirect(url_for("login"))
    return render_template("register.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "").strip()
        with Session(engine) as s:
            u = s.scalar(select(User).where(User.username == username))
            if not u and not password:
                flash("ไม่มีชื่อนี้ในระบบ และไม่ได้กรอกรหัสผ่าน", "danger")
            elif not u:
                flash("ไม่มีชื่อนี้ในระบบ", "danger")
            elif not verify_password(password, u.password_hash):
                flash("รหัสผ่านไม่ถูกต้อง", "danger")
            else:
                session["uid"] = u.id
                return redirect(url_for("dashboard"))
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))

# ---------- Dashboard ----------
@app.route("/")
def index():
    if not current_user():
        return redirect(url_for("login"))
    return redirect(url_for("dashboard"))

@app.route("/dashboard")
def dashboard():
    u = current_user()
    if not u: return redirect(url_for("login"))
    with Session(engine) as s:
        projects = s.scalars(select(Project).where(Project.owner_id == u.id)).all()
    return render_template("dashboard.html", projects=projects, runners=RUNNERS)

@app.route("/project/create", methods=["POST"])
def project_create():
    u = current_user()
    if not u: return redirect(url_for("login"))
    name = request.form["name"].strip() or "My Project"
    version = "v1"
    langs = request.form.getlist("languages")
    langs = langs[:5] if langs else ["python"]
    slug = slugify(f"{name}-{u.id}-{int(time.time())}")
    ws_path = pathlib.Path(WORKSPACE_BASE) / slug
    ws_path.mkdir(parents=True, exist_ok=True)

    # Seed default files/categories like the screenshot vibe
    categories = ["behavior_packs","config","definitions","resource_packs"]
    defaults = {
        "python": ("main.py", 'print("Hello from Python v1")\n'),
        "node": ("index.js", 'console.log("Hello from Node v1")\n'),
        "php": ("index.php", '<?php echo "Hello from PHP v1\\n"; ?>\n'),
        "java": ("Main.java", 'public class Main{public static void main(String[]a){System.out.println("Hello from Java v1");}}\n'),
        "go": ("main.go", 'package main\nimport "fmt"\nfunc main(){fmt.Println("Hello from Go v1")}\n')
    }

    with Session(engine) as s:
        p = Project(owner_id=u.id, name=name, slug=slug, version=version, languages=",".join(langs))
        s.add(p); s.commit()
        # Seed file records and disk
        for c in categories:
            (ws_path / c).mkdir(parents=True, exist_ok=True)
        for lang in langs:
            fname, content = defaults[lang]
            (ws_path / fname).write_text(content, encoding="utf-8")
            fr = FileRecord(project_id=p.id, path=fname, content=content)
            s.add(fr)
        s.commit()
    flash("สร้างโปรเจกต์ v1 สำเร็จ", "success")
    return redirect(url_for("project_view", slug=slug))

@app.route("/project/<slug>")
def project_view(slug):
    u = current_user()
    if not u: return redirect(url_for("login"))
    with Session(engine) as s:
        p = s.scalar(select(Project).where(Project.slug == slug))
        if not p or p.owner_id != u.id: return redirect(url_for("dashboard"))
        files = s.scalars(select(FileRecord).where(FileRecord.project_id == p.id)).all()
    return render_template("project.html", p=p, files=files, runners=RUNNERS)

@app.route("/project/<slug>/file/save", methods=["POST"])
def file_save(slug):
    u = current_user()
    if not u: return ("", 403)
    relpath = request.form["path"].strip()
    content = request.form["content"]
    with Session(engine) as s:
        p = s.scalar(select(Project).where(Project.slug == slug))
        if not p or p.owner_id != u.id: return ("", 403)
        fr = s.scalar(select(FileRecord).where(FileRecord.project_id==p.id, FileRecord.path==relpath))
        if not fr:
            fr = FileRecord(project_id=p.id, path=relpath, content=content)
            s.add(fr)
        else:
            fr.content = content
        s.commit()
    ws_path = pathlib.Path(WORKSPACE_BASE) / slug
    (ws_path / relpath).parent.mkdir(parents=True, exist_ok=True)
    (ws_path / relpath).write_text(content, encoding="utf-8")
    return "ok"

@app.route("/project/<slug>/run", methods=["POST"])
def project_run(slug):
    u = current_user()
    if not u: return ("", 403)
    langs = request.form.getlist("languages")
    entries = request.form.getlist("entries")  # parallel arrays
    with Session(engine) as s:
        p = s.scalar(select(Project).where(Project.slug == slug))
        if not p or p.owner_id != u.id: return ("", 403)
        run = Run(project_id=p.id, languages=",".join(langs), entrypoints=",".join(entries), status="running", logs="")
        s.add(run); s.commit()
        run_id = run.id
    # Launch containers sequentially and capture logs
    ws_path = pathlib.Path(WORKSPACE_BASE) / slug
    aggregated = []
    for lang, entry in zip(langs, entries):
        spec = RUNNERS[lang]
        image = spec["image"]
        entry = entry or spec["default_entry"]
        cmd_template = spec["run"]
        if lang == "java":
            cmd = cmd_template.format(entry=entry, classname=os.path.splitext(os.path.basename(entry))[0])
        else:
            cmd = cmd_template.format(entry=entry)
        docker_cmd = f'{DOCKER_BIN} run --rm -m 512m --cpus=1 -v {ws_path}:/code -w /code {image} {cmd}'
        try:
            out = subprocess.check_output(docker_cmd, shell=True, stderr=subprocess.STDOUT, timeout=120)
            aggregated.append(f"[{lang}]\\n" + out.decode())
        except subprocess.CalledProcessError as e:
            aggregated.append(f"[{lang} ERROR]\\n" + e.output.decode())
        except subprocess.TimeoutExpired:
            aggregated.append(f"[{lang} ERROR] Timeout")
    with Session(engine) as s:
        r = s.get(Run, run_id)
        r.status = "finished"
        r.finished_at = datetime.utcnow()
        r.logs = "\\n\\n".join(aggregated)
        s.commit()
    return redirect(url_for("run_view", run_id=run_id))

@app.route("/run/<int:run_id>")
def run_view(run_id):
    u = current_user()
    if not u: return redirect(url_for("login"))
    with Session(engine) as s:
        r = s.get(Run, run_id)
        p = s.get(Project, r.project_id) if r else None
        if not r or not p or p.owner_id != u.id: return redirect(url_for("dashboard"))
    return render_template("run.html", r=r, p=p)

@app.route("/download/<slug>/<path:rel>")
def download_file(slug, rel):
    u = current_user()
    if not u: return ("", 403)
    ws_path = pathlib.Path(WORKSPACE_BASE) / slug
    return send_from_directory(ws_path, rel, as_attachment=True)

# Static workspace browser (list files under workspace base)
@app.route("/project/<slug>/ls")
def list_files(slug):
    u = current_user()
    if not u: return ("", 403)
    ws_path = pathlib.Path(WORKSPACE_BASE) / slug
    result = []
    for p in ws_path.rglob("*"):
        if p.is_file():
            result.append(str(p.relative_to(ws_path)))
    return jsonify(result)

if __name__ == "__main__":
    app.run(host=os.environ.get("HOST","0.0.0.0"), port=int(os.environ.get("PORT","8080")), debug=os.environ.get("DEBUG","false").lower()=="true")
