
import os
import subprocess
from datetime import datetime

from flask import Flask, render_template, redirect, url_for, request, flash
from flask_sqlalchemy import SQLAlchemy
from flask_login import (
    LoginManager,
    UserMixin,
    login_user,
    login_required,
    logout_user,
    current_user,
)
from werkzeug.security import generate_password_hash, check_password_hash

# -----------------------------------------------------------------------------
# Config
# -----------------------------------------------------------------------------
BASE_DIR = os.path.abspath(os.path.dirname(__file__))

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "change-this-secret-key")
app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get(
    "DATABASE_URL", f"sqlite:///{os.path.join(BASE_DIR, 'site.db')}"
)
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["PROJECT_ROOT"] = os.path.join(BASE_DIR, "projects")

db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = "login"

# -----------------------------------------------------------------------------
# Models
# -----------------------------------------------------------------------------
class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def set_password(self, password: str) -> None:
        self.password_hash = generate_password_hash(password)

    def check_password(self, password: str) -> bool:
        return check_password_hash(self.password_hash, password)


class Project(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    name = db.Column(db.String(128), nullable=False)
    language = db.Column(db.String(32), nullable=False)
    run_command = db.Column(db.String(255), nullable=False)
    directory = db.Column(db.String(255), nullable=False)
    session_name = db.Column(db.String(64), nullable=False)
    status = db.Column(db.String(16), default="stopped")
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    user = db.relationship("User", backref=db.backref("projects", lazy=True))


@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))


# -----------------------------------------------------------------------------
# Helpers
# -----------------------------------------------------------------------------
LANG_CONFIG = {
    "python": {
        "label": "Python",
        "main_file": "main.py",
        "run_command": "python3 main.py",
        "template": 'print("Hello from your Python bot!")\n',
    },
    "node": {
        "label": "Node.js",
        "main_file": "index.js",
        "run_command": "node index.js",
        "template": 'console.log("Hello from your Node.js bot!");\n',
    },
    "php": {
        "label": "PHP",
        "main_file": "index.php",
        "run_command": "php -S 0.0.0.0:8000",
        "template": '<?php echo "Hello from your PHP project!";\n',
    },
}

def ensure_project_root():
    project_root = app.config["PROJECT_ROOT"]
    os.makedirs(project_root, exist_ok=True)
    return project_root


def create_project_dir(project: Project):
    project_root = ensure_project_root()
    user_folder = os.path.join(project_root, f"user_{project.user_id}")
    os.makedirs(user_folder, exist_ok=True)

    project_folder = os.path.join(user_folder, f"project_{project.id}")
    os.makedirs(project_folder, exist_ok=True)

    lang_cfg = LANG_CONFIG.get(project.language)
    if lang_cfg:
        main_path = os.path.join(project_folder, lang_cfg["main_file"])
        if not os.path.exists(main_path):
            with open(main_path, "w", encoding="utf-8") as f:
                f.write(lang_cfg["template"])

        # Optional CSS file so Python/Node สามารถใช้ร่วมกับ CSS ได้
        css_path = os.path.join(project_folder, "style.css")
        if not os.path.exists(css_path):
            with open(css_path, "w", encoding="utf-8") as f:
                f.write("/* Custom styles for your project */\n")

    # บันทึก directory ลง DB
    project.directory = project_folder
    db.session.commit()


def get_project_main_paths(project: Project):
    lang_cfg = LANG_CONFIG.get(project.language)
    if not lang_cfg:
        return None, None

    main_path = os.path.join(project.directory, lang_cfg["main_file"])
    css_path = os.path.join(project.directory, "style.css")
    return main_path, css_path


def start_project_session(project: Project):
    """ใช้ tmux รันโปรเจกต์แบบ background (ต้องติดตั้ง tmux ก่อน)."""
    if not project.directory:
        create_project_dir(project)

    lang_cfg = LANG_CONFIG.get(project.language)
    if not lang_cfg:
        raise RuntimeError("ไม่รองรับภาษาโปรแกรมนี้ใน v1")

    session_name = project.session_name
    cmd = f"cd {project.directory} && {lang_cfg['run_command']}"

    # tmux new-session -d -s session_name 'command'
    try:
        subprocess.check_call(["tmux", "new-session", "-d", "-s", session_name, cmd])
        project.status = "running"
        db.session.commit()
    except Exception as e:
        raise RuntimeError(f"ไม่สามารถรันโปรเจกต์ได้: {e}")


def stop_project_session(project: Project):
    try:
        subprocess.check_call(["tmux", "kill-session", "-t", project.session_name])
    except subprocess.CalledProcessError:
        # ถ้าไม่มี session ก็ข้ามไป
        pass
    project.status = "stopped"
    db.session.commit()


# -----------------------------------------------------------------------------
# Routes - Auth
# -----------------------------------------------------------------------------
@app.route("/")
def index():
    if current_user.is_authenticated:
        return redirect(url_for("dashboard"))
    return render_template("index.html")


@app.route("/register", methods=["GET", "POST"])
def register():
    if current_user.is_authenticated:
        return redirect(url_for("dashboard"))

    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        confirm = request.form.get("confirm", "")

        if not username or not password:
            flash("กรุณากรอกชื่อผู้ใช้และรหัสผ่าน", "danger")
            return redirect(url_for("register"))

        if password != confirm:
            flash("รหัสผ่านยืนยันไม่ตรงกัน", "danger")
            return redirect(url_for("register"))

        existing = User.query.filter_by(username=username).first()
        if existing:
            flash("ชื่อผู้ใช้นี้ถูกใช้แล้ว", "danger")
            return redirect(url_for("register"))

        user = User(username=username)
        user.set_password(password)
        db.session.add(user)
        db.session.commit()
        flash("สมัครสมาชิกสำเร็จ! กรุณาเข้าสู่ระบบ", "success")
        return redirect(url_for("login"))

    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if current_user.is_authenticated:
        return redirect(url_for("dashboard"))

    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")

        user = User.query.filter_by(username=username).first()
        if user is None:
            flash("ไม่มีชื่อนี้ในระบบ", "danger")
            return redirect(url_for("login"))

        if not user.check_password(password):
            flash("รหัสผ่านไม่ถูกต้อง", "danger")
            return redirect(url_for("login"))

        login_user(user)
        flash("เข้าสู่ระบบสำเร็จ", "success")
        return redirect(url_for("dashboard"))

    return render_template("login.html")


@app.route("/logout")
@login_required
def logout():
    logout_user()
    flash("ออกจากระบบแล้ว", "info")
    return redirect(url_for("index"))


# -----------------------------------------------------------------------------
# Routes - Projects
# -----------------------------------------------------------------------------
@app.route("/dashboard")
@login_required
def dashboard():
    projects = Project.query.filter_by(user_id=current_user.id).order_by(Project.created_at.desc()).all()
    return render_template("dashboard.html", projects=projects, lang_config=LANG_CONFIG)


@app.route("/projects/new", methods=["GET", "POST"])
@login_required
def new_project():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        language = request.form.get("language", "python")

        if not name:
            flash("กรุณากรอกชื่อโปรเจกต์", "danger")
            return redirect(url_for("new_project"))

        if language not in LANG_CONFIG:
            flash("ภาษาโปรแกรมนี้ยังไม่รองรับใน v1", "danger")
            return redirect(url_for("new_project"))

        # สร้างโปรเจกต์ใน DB ก่อน เพื่อให้มี ID
        session_name = f"proj_{current_user.id}_{int(datetime.utcnow().timestamp())}"
        project = Project(
            user_id=current_user.id,
            name=name,
            language=language,
            run_command=LANG_CONFIG[language]["run_command"],
            directory="",
            session_name=session_name,
            status="stopped",
        )
        db.session.add(project)
        db.session.commit()

        # สร้างโฟลเดอร์ + main file + css
        create_project_dir(project)

        flash("สร้างโปรเจกต์สำเร็จ", "success")
        return redirect(url_for("dashboard"))

    return render_template("new_project.html", lang_config=LANG_CONFIG)


@app.route("/projects/<int:project_id>", methods=["GET", "POST"])
@login_required
def project_detail(project_id):
    project = Project.query.get_or_404(project_id)
    if project.user_id != current_user.id:
        flash("คุณไม่มีสิทธิ์เข้าถึงโปรเจกต์นี้", "danger")
        return redirect(url_for("dashboard"))

    main_path, css_path = get_project_main_paths(project)

    if request.method == "POST":
        main_code = request.form.get("main_code", "")
        css_code = request.form.get("css_code", "")

        if main_path:
            with open(main_path, "w", encoding="utf-8") as f:
                f.write(main_code)

        if css_path:
            with open(css_path, "w", encoding="utf-8") as f:
                f.write(css_code)

        flash("บันทึกโค้ดเรียบร้อย", "success")
        return redirect(url_for("project_detail", project_id=project.id))

    main_code = ""
    css_code = ""
    if main_path and os.path.exists(main_path):
        with open(main_path, "r", encoding="utf-8") as f:
            main_code = f.read()
    if css_path and os.path.exists(css_path):
        with open(css_path, "r", encoding="utf-8") as f:
            css_code = f.read()

    return render_template(
        "project_detail.html",
        project=project,
        main_code=main_code,
        css_code=css_code,
        lang_config=LANG_CONFIG,
    )


@app.route("/projects/<int:project_id>/run", methods=["POST"])
@login_required
def run_project(project_id):
    project = Project.query.get_or_404(project_id)
    if project.user_id != current_user.id:
        flash("คุณไม่มีสิทธิ์รันโปรเจกต์นี้", "danger")
        return redirect(url_for("dashboard"))

    try:
        start_project_session(project)
        flash("เริ่มรันโปรเจกต์แล้ว (background ผ่าน tmux)", "success")
    except Exception as e:
        flash(str(e), "danger")
    return redirect(url_for("dashboard"))


@app.route("/projects/<int:project_id>/stop", methods=["POST"])
@login_required
def stop_project(project_id):
    project = Project.query.get_or_404(project_id)
    if project.user_id != current_user.id:
        flash("คุณไม่มีสิทธิ์หยุดโปรเจกต์นี้", "danger")
        return redirect(url_for("dashboard"))

    stop_project_session(project)
    flash("หยุดโปรเจกต์แล้ว", "info")
    return redirect(url_for("dashboard"))


# -----------------------------------------------------------------------------
# CLI
# -----------------------------------------------------------------------------
@app.cli.command("init-db")
def init_db_command():
    """สร้างฐานข้อมูล (ใช้ครั้งแรก)."""
    db.create_all()
    print("ฐานข้อมูลถูกสร้างแล้ว.")


if __name__ == "__main__":
    ensure_project_root()
    with app.app_context():
        db.create_all()
    # ใช้ host=0.0.0.0 เพื่อให้เข้าจากภายนอก VPS ได้
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)), debug=True)
