# เว็บไซต์รันบอทบน VPS v1

โปรเจกต์นี้เป็นเว็บตัวอย่างสำหรับรันบอท/สคริปต์บน VPS คล้าย Replit (เวอร์ชัน v1)

## ฟีเจอร์หลัก

- สมัครสมาชิก / ล็อกอิน
- สร้างโปรเจกต์ (รองรับภาษา: Python, Node.js, PHP ใน v1)
- แต่ละโปรเจกต์มีโฟลเดอร์แยกเก็บไฟล์
- มีไฟล์หลัก (main.py / index.js / index.php) และไฟล์ style.css ให้ใช้งานร่วมกัน
- ปุ่ม Run / Stop โปรเจกต์ (รัน background ด้วย tmux)

> หมายเหตุ: v1 เป็นตัวอย่างพื้นฐาน ยังไม่ได้แยก container หรือ sandbox ระดับลึกแบบ Replit จริง

## การใช้งานบน VPS (Ubuntu ตัวอย่าง)

```bash
# 1) อัปเดตและติดตั้ง Python + pip
sudo apt update && sudo apt upgrade -y
sudo apt install -y python3 python3-pip python3-venv tmux

# 2) ดาวน์โหลดโปรเจกต์จาก GitHub (ตัวอย่าง)
# git clone https://github.com/yourname/bot_runner_v1.git
cd bot_runner_v1

# 3) สร้าง venv และติดตั้งไลบรารี
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt

# 4) ตั้งค่าสิ่งแวดล้อม (ปรับ SECRET_KEY เอง)
export SECRET_KEY="some-strong-secret-key"

# 5) สร้างฐานข้อมูล
flask --app app.py init-db

# 6) รันเว็บ
python app.py
# หรือ
flask --app app.py run --host=0.0.0.0 --port=5000
```

เปิดเบราว์เซอร์ไปที่ `http://YOUR_VPS_IP:5000`

## หมายเหตุเรื่องการรันบอท

- ระบบใช้ `tmux` รันโปรเจกต์แต่ละอันใน background
- ตรวจสอบ session ที่กำลังรันอยู่:

```bash
tmux ls
```

- เข้าดู log ของโปรเจกต์ (ตัวอย่าง):

```bash
tmux attach -t proj_XXXXXXXX
# ออกจากหน้าจอ tmux โดยไม่หยุดโปรเซส: กด Ctrl+B แล้ว D
```

คุณสามารถนำโปรเจกต์นี้ไปต่อยอด:
- เพิ่มภาษาอื่น ๆ (Go, Java, C#, ฯลฯ)
- เพิ่ม code editor แบบเต็ม (เช่น Monaco)
- เพิ่มระบบจำกัดทรัพยากร / sandbox
